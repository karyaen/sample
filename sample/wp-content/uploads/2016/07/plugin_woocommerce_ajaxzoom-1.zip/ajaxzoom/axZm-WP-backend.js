
jQuery( document ).ready(function($) {
    $('label', $('.ajaxzoom-useful').parent().parent()).addClass('az-ec971f').prepend('<i class="az-icon-gear" style="margin-right: 5px;"></i>');
    $('label', $('.ajaxzoom-important').parent().parent()).addClass('az-c9302c').prepend('<i class="az-icon-hand" style="margin-right: 5px;"></i>')
});