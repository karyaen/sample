<?php
	// You can copy and change any configurations from /axZm/zoomConfig.inc.php or /axZm/zoomConfigCustom.inc.php
	// All settings you have here overwrite from the above
	
?>